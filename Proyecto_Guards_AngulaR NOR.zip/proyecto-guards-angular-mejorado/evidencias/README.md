# Evidencias de validación

Esta carpeta contiene las seis imágenes solicitadas por la actividad.

Para regenerarlas directamente desde la aplicación Angular en funcionamiento:

```bash
npm install
npm run e2e:install
npm run e2e
```

Playwright iniciará el servidor Angular, ejecutará los seis escenarios y reemplazará las capturas de esta carpeta.
