import { expect, test, type Page } from '@playwright/test';
import { mkdirSync } from 'node:fs';

const evidenceDirectory = 'evidencias';
const email = 'admin@guardapp.com';
const password = '123456';

async function clearSession(page: Page): Promise<void> {
  await page.goto('/login');
  await page.evaluate(() => localStorage.clear());
  await page.reload();
}

async function login(page: Page): Promise<void> {
  await page.goto('/login');
  await page.getByTestId('email').fill(email);
  await page.getByTestId('password').fill(password);
  await page.getByTestId('login-button').click();
  await expect(page).toHaveURL(/\/dashboard$/);
}

test.beforeAll(() => {
  mkdirSync(evidenceDirectory, { recursive: true });
});

test('Caso 1: /login sin autenticarse muestra el Login', async ({ page }) => {
  await clearSession(page);
  await page.goto('/login');

  await expect(page.getByRole('heading', { name: 'Iniciar sesión' })).toBeVisible();
  await expect(page).toHaveURL(/\/login$/);
  await page.screenshot({
    path: `${evidenceDirectory}/caso-01-login-sin-autenticacion.png`,
    fullPage: true,
  });
});

test('Caso 2: /dashboard sin autenticarse redirige al Login', async ({ page }) => {
  await clearSession(page);
  await page.goto('/dashboard');

  await expect(page).toHaveURL(/\/login\?returnUrl=%2Fdashboard/);
  await expect(page.getByTestId('authguard-notice')).toBeVisible();
  await page.screenshot({
    path: `${evidenceDirectory}/caso-02-dashboard-sin-autenticacion.png`,
    fullPage: true,
  });
});

test('Caso 3: credenciales válidas muestran el Dashboard', async ({ page }) => {
  await clearSession(page);
  await login(page);

  await expect(page.getByRole('heading', { name: /Bienvenido/ })).toBeVisible();
  await expect
    .poll(() => page.evaluate(() => localStorage.getItem('guard_app_token')))
    .not.toBeNull();
  await page.screenshot({
    path: `${evidenceDirectory}/caso-03-login-valido-dashboard.png`,
    fullPage: true,
  });
});

test('Caso 4: /login autenticado redirige al Dashboard', async ({ page }) => {
  await clearSession(page);
  await login(page);
  await page.goto('/login');

  await expect(page).toHaveURL(/\/dashboard$/);
  await expect(page.getByRole('heading', { name: /Bienvenido/ })).toBeVisible();
  await page.screenshot({
    path: `${evidenceDirectory}/caso-04-login-autenticado.png`,
    fullPage: true,
  });
});

test('Caso 5: cerrar sesión elimina el token y muestra el Login', async ({ page }) => {
  await clearSession(page);
  await login(page);
  await page.getByTestId('logout-button').click();

  await expect(page).toHaveURL(/\/login\?loggedOut=1/);
  await expect(page.getByTestId('logout-notice')).toBeVisible();
  await expect
    .poll(() => page.evaluate(() => localStorage.getItem('guard_app_token')))
    .toBeNull();
  await page.screenshot({
    path: `${evidenceDirectory}/caso-05-cerrar-sesion.png`,
    fullPage: true,
  });
});

test('Caso 6: /dashboard después de cerrar sesión redirige al Login', async ({ page }) => {
  await clearSession(page);
  await login(page);
  await page.getByTestId('logout-button').click();
  await page.goto('/dashboard');

  await expect(page).toHaveURL(/\/login\?returnUrl=%2Fdashboard/);
  await expect(page.getByTestId('authguard-notice')).toBeVisible();
  await page.screenshot({
    path: `${evidenceDirectory}/caso-06-dashboard-despues-logout.png`,
    fullPage: true,
  });
});

test('Validación adicional: credenciales incorrectas no crean sesión', async ({ page }) => {
  await clearSession(page);
  await page.getByTestId('email').fill(email);
  await page.getByTestId('password').fill('incorrecta');
  await page.getByTestId('login-button').click();

  await expect(page.getByTestId('login-error')).toBeVisible();
  await expect(page).toHaveURL(/\/login$/);
  const token = await page.evaluate(() => localStorage.getItem('guard_app_token'));
  expect(token).toBeNull();
});
