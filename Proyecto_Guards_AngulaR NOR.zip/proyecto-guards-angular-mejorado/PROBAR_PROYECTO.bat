@echo off
chcp 65001 >nul
cd /d "%~dp0"

call npm install
if errorlevel 1 exit /b 1

call npm run verify
if errorlevel 1 exit /b 1

call npm run build
if errorlevel 1 exit /b 1

call npm test
if errorlevel 1 exit /b 1

echo Proyecto compilado y pruebas unitarias completadas.
pause
