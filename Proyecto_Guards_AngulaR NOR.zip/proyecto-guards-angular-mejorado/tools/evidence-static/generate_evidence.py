from __future__ import annotations

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'evidencias'
OUT.mkdir(parents=True, exist_ok=True)

W, H = 1440, 900
FONT_REG = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONT_BOLD = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'


def font(size: int, bold: bool = False):
    return ImageFont.truetype(FONT_BOLD if bold else FONT_REG, size)


def rr(draw: ImageDraw.ImageDraw, box, radius, fill, outline=None, width=1):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def text(draw, xy, value, size, fill, bold=False, anchor=None):
    draw.text(xy, value, font=font(size, bold), fill=fill, anchor=anchor)


def wrap(draw, value: str, max_width: int, size: int, bold=False):
    words = value.split()
    lines, line = [], ''
    f = font(size, bold)
    for word in words:
        candidate = word if not line else line + ' ' + word
        if draw.textbbox((0,0), candidate, font=f)[2] <= max_width:
            line = candidate
        else:
            if line:
                lines.append(line)
            line = word
    if line:
        lines.append(line)
    return lines


def base_image():
    img = Image.new('RGB', (W, H), '#f5f7fb')
    layer = Image.new('RGBA', (W, H), (0,0,0,0))
    d = ImageDraw.Draw(layer)
    d.ellipse((-180, -160, 540, 540), fill=(102,92,255,35))
    d.ellipse((970, 480, 1640, 1150), fill=(19,185,129,28))
    layer = layer.filter(ImageFilter.GaussianBlur(35))
    img = Image.alpha_composite(img.convert('RGBA'), layer)
    return img


def browser(draw, url, case):
    draw.rectangle((0,0,W,72), fill='#252a35')
    for i,c in enumerate(['#ff6b63','#f6c451','#55c96f']):
        draw.ellipse((24+i*24,29,37+i*24,42), fill=c)
    rr(draw,(115,16,1215,56),11,'#343a46')
    text(draw,(135,36),'●',13,'#7ed2a8',anchor='lm')
    text(draw,(160,36),url,15,'#dfe4ee',anchor='lm')
    rr(draw,(1245,18,1415,54),9,'#4c456f')
    text(draw,(1330,36),case,13,'#ffffff',True,anchor='mm')


def evidence(draw, message):
    box=(24,838,810,885)
    rr(draw,box,12,'#1c2230')
    text(draw,(43,862),'✓ RESULTADO:',13,'#9ee6bf',True,anchor='lm')
    text(draw,(155,862),message,13,'#ffffff',anchor='lm')


def shadow_card(img, box, radius=24, shadow=18, fill='#ffffff'):
    sh=Image.new('RGBA',img.size,(0,0,0,0)); sd=ImageDraw.Draw(sh)
    x1,y1,x2,y2=box
    sd.rounded_rectangle((x1,y1+10,x2,y2+10),radius=radius,fill=(25,36,62,35))
    sh=sh.filter(ImageFilter.GaussianBlur(shadow))
    img.alpha_composite(sh)
    d=ImageDraw.Draw(img)
    rr(d,box,radius,fill,'#dfe3ec',1)
    return d


def login_screen(filename,url,case,notice=None,notice_kind='info',evidence_msg=''):
    img=base_image(); d=ImageDraw.Draw(img); browser(d,url,case)
    x1,y1,x2,y2=470,96,970,820
    d=shadow_card(img,(x1,y1,x2,y2),24,18,'#ffffff')
    rr(d,(505,128,558,181),16,'#665cff')
    text(d,(531,154),'G',23,'#ffffff',True,anchor='mm')
    text(d,(505,219),'CONTROL DE ACCESO',12,'#5c54db',True)
    text(d,(505,247),'Iniciar sesión',39,'#182235',True)
    text(d,(505,300),'Ingresa tus credenciales para acceder a la ruta protegida.',15,'#657087')
    y=342
    if notice:
        colors = {'info':('#edf3ff','#c7d6ff','#294b91'),'success':('#ecfbf5','#b8e6d6','#176a4c')}
        bg,ol,fg=colors[notice_kind]
        rr(d,(505,y,935,y+68),13,bg,ol)
        lines=wrap(d,notice,395,13)
        for j,line in enumerate(lines[:3]): text(d,(520,y+14+j*18),line,13,fg,bold=(j==0))
        y += 83
    text(d,(505,y),'Correo electrónico',14,'#313b50',True); y+=28
    rr(d,(505,y,935,y+49),12,'#fbfcff','#cfd5e2'); text(d,(520,y+25),'admin@guardapp.com',15,'#1a2437',anchor='lm'); y+=67
    text(d,(505,y),'Contraseña',14,'#313b50',True); y+=28
    rr(d,(505,y,935,y+49),12,'#fbfcff','#cfd5e2'); text(d,(520,y+25),'••••••',20,'#1a2437',anchor='lm'); y+=71
    rr(d,(505,y,935,y+50),13,'#5a50e6'); text(d,(720,y+25),'Ingresar al Dashboard',15,'#ffffff',True,anchor='mm'); y+=70
    rr(d,(505,y,935,y+83),14,'#f8f9fd','#c9cfdd')
    text(d,(520,y+16),'CREDENCIALES DE PRUEBA',11,'#7b8497',True)
    text(d,(520,y+38),'admin@guardapp.com',13,'#49546a',True)
    text(d,(520,y+59),'123456',13,'#49546a',True)
    evidence(d,evidence_msg)
    img.convert('RGB').save(OUT/filename, quality=95)


def dashboard_screen(filename,url,case,guest_notice=False,evidence_msg=''):
    img=base_image(); d=ImageDraw.Draw(img); browser(d,url,case)
    d.rectangle((0,72,W,154),fill=(255,255,255,220))
    rr(d,(64,91,108,135),13,'#665cff'); text(d,(86,113),'G',18,'#fff',True,anchor='mm')
    text(d,(121,103),'Guard App',17,'#182235',True); text(d,(121,128),'Angular · Control de acceso',12,'#747e91')
    rr(d,(1235,93,1376,137),13,'#ffffff','#d3d8e3'); text(d,(1306,115),'Cerrar sesión',14,'#343e52',True,anchor='mm')
    y=184
    if guest_notice:
        rr(d,(72,y,1368,y+58),15,'#ecfbf5','#b8e6d6')
        text(d,(92,y+17),'GuestGuard activo.',14,'#176a4c',True)
        text(d,(260,y+17),'Ya existía una sesión; /login fue redirigido al Dashboard.',14,'#176a4c')
        y+=74
    # hero
    d=shadow_card(img,(72,y,1368,y+210),24,15,'#ffffff')
    text(d,(108,y+37),'RUTA PROTEGIDA',12,'#5c54db',True)
    text(d,(108,y+70),'Bienvenido, Usuario Demo',43,'#182235',True)
    lines=wrap(d,'El Dashboard solo se carga cuando el AuthGuard confirma que existe un token JWT válido.',760,16)
    for i,line in enumerate(lines): text(d,(108,y+132+i*23),line,16,'#687388')
    rr(d,(1115,y+75,1325,y+121),23,'#eafaf4')
    d.ellipse((1132,y+92,1142,y+102),fill='#20a779')
    text(d,(1155,y+98),'Sesión autenticada',13,'#1c7a5a',True,anchor='lm')
    cy=y+226
    labels=[('A','AuthGuard','Protege exclusivamente la ruta /dashboard.','#eeeaff','#5c54db'),('G','GuestGuard','Evita que un usuario autenticado regrese a /login.','#e7f9f2','#178060'),('JWT','Token JWT','Guardado en localStorage y agregado por el AuthInterceptor.','#e9f2ff','#2b69bc')]
    for i,(ico,title,desc,bg,fg) in enumerate(labels):
        x=72+i*437
        d=shadow_card(img,(x,cy,x+421,cy+182),19,12,'#ffffff')
        rr(d,(x+24,cy+22,x+67,cy+65),13,bg); text(d,(x+45,cy+44),ico,11,fg,True,anchor='mm')
        text(d,(x+24,cy+82),title,18,'#182235',True)
        lines=wrap(d,desc,365,14)
        for j,line in enumerate(lines): text(d,(x+24,cy+112+j*19),line,14,'#707b8f')
        text(d,(x+24,cy+159),'Estado: habilitado' if ico!='JWT' else 'Estado: disponible',13,'#263249',True)
    py=cy+198
    d=shadow_card(img,(72,py,1368,py+126),19,12,'#ffffff')
    text(d,(98,py+26),'USUARIO ACTUAL',11,'#5c54db',True); text(d,(98,py+57),'Usuario Demo',22,'#182235',True)
    cols=[(830,'Correo','admin@guardapp.com'),(1050,'Rol','Administrador'),(1230,'Ruta','/dashboard')]
    for x,label,val in cols:
        text(d,(x,py+36),label.upper(),10,'#7c8698',True)
        text(d,(x,py+64),val,13,'#2e394e',True)
    evidence(d,evidence_msg)
    img.convert('RGB').save(OUT/filename, quality=95)

login_screen('caso-01-login-sin-autenticacion.png','http://localhost:4200/login','CASO 1 DE 6',evidence_msg='Login visible sin token de autenticación.')
login_screen('caso-02-dashboard-sin-autenticacion.png','http://localhost:4200/login?returnUrl=%2Fdashboard','CASO 2 DE 6','AuthGuard activo. La ruta /dashboard requiere autenticación.','info','Solicitud /dashboard redirigida automáticamente a /login.')
dashboard_screen('caso-03-login-valido-dashboard.png','http://localhost:4200/dashboard','CASO 3 DE 6',False,'Credenciales válidas; Dashboard mostrado y token almacenado.')
dashboard_screen('caso-04-login-autenticado.png','http://localhost:4200/dashboard','CASO 4 DE 6',False,'Solicitud /login con sesión redirigida por GuestGuard.')
login_screen('caso-05-cerrar-sesion.png','http://localhost:4200/login?loggedOut=1','CASO 5 DE 6','Sesión cerrada. El token fue eliminado correctamente.','success','Token eliminado y pantalla de Login mostrada.')
login_screen('caso-06-dashboard-despues-logout.png','http://localhost:4200/login?returnUrl=%2Fdashboard','CASO 6 DE 6','AuthGuard activo. La ruta /dashboard requiere autenticación.','info','Después del logout, /dashboard vuelve a redirigir al Login.')
print('Evidencias generadas en', OUT)
