import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const requiredFiles = [
  'angular.json',
  'package.json',
  'src/main.ts',
  'src/app/app.routes.ts',
  'src/app/core/guards/auth.guard.ts',
  'src/app/core/guards/guest.guard.ts',
  'src/app/core/services/auth.service.ts',
  'src/app/core/interceptors/auth.interceptor.ts',
  'src/app/features/auth/login/login.component.ts',
  'src/app/features/dashboard/dashboard.component.ts',
  'e2e/guards.spec.ts',
];

const errors = [];

for (const file of requiredFiles) {
  if (!existsSync(resolve(root, file))) {
    errors.push(`Falta el archivo requerido: ${file}`);
  }
}

const packageJson = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'));
if (!packageJson.scripts?.start || !packageJson.scripts?.build || !packageJson.scripts?.test) {
  errors.push('package.json debe incluir scripts start, build y test.');
}

const routes = readFileSync(resolve(root, 'src/app/app.routes.ts'), 'utf8');
if (!/path:\s*'dashboard'[\s\S]*canActivate:\s*\[AuthGuard\]/.test(routes)) {
  errors.push('La ruta dashboard no está protegida con AuthGuard.');
}
if (!/path:\s*'login'[\s\S]*canActivate:\s*\[GuestGuard\]/.test(routes)) {
  errors.push('La ruta login no está protegida con GuestGuard.');
}

const guestGuard = readFileSync(
  resolve(root, 'src/app/core/guards/guest.guard.ts'),
  'utf8',
);
if (!guestGuard.includes("createUrlTree(['/dashboard'])")) {
  errors.push('GuestGuard no redirige a /dashboard.');
}

const authGuard = readFileSync(
  resolve(root, 'src/app/core/guards/auth.guard.ts'),
  'utf8',
);
if (!authGuard.includes("createUrlTree(['/login']")) {
  errors.push('AuthGuard no redirige a /login.');
}

const major = Number(process.versions.node.split('.')[0]);
if (major < 20 || major >= 25) {
  errors.push(`Node.js ${process.versions.node} no es compatible. Usa Node.js 20, 22 o 24.`);
}

if (errors.length > 0) {
  console.error('\nVERIFICACIÓN FALLIDA\n');
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log('VERIFICACIÓN CORRECTA');
console.log('- Estructura del proyecto completa.');
console.log('- Dashboard protegido con AuthGuard.');
console.log('- Login protegido con GuestGuard.');
console.log('- Scripts de ejecución, compilación y pruebas disponibles.');
console.log(`- Node.js detectado: ${process.versions.node}.`);
