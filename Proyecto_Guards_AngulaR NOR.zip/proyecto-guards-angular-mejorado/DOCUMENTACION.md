# Informe: Implementación de Guards para el control de acceso

## 1. Objetivo

Implementar mecanismos de control de acceso en una aplicación Angular para proteger el Dashboard según el estado de autenticación y evitar que un usuario autenticado vuelva a la pantalla de Login.

## 2. AuthGuard

El `AuthGuard` se aplica únicamente a `/dashboard`.

- Si `AuthService.isAuthenticated()` devuelve `true`, permite la navegación.
- Si no existe una sesión válida, devuelve un `UrlTree` hacia `/login`.
- La ruta solicitada se conserva en el parámetro `returnUrl` para regresar al Dashboard después del inicio de sesión.

Se devuelve un `UrlTree` en lugar de ejecutar una navegación dentro del Guard, evitando navegaciones duplicadas.

## 3. GuestGuard

El `GuestGuard` se aplica únicamente a `/login`.

- Si el usuario no está autenticado, devuelve `true` y permite mostrar el Login.
- Si el usuario ya está autenticado, devuelve un `UrlTree` hacia `/dashboard`.

Así se evita que un usuario con sesión activa vuelva a la pantalla de autenticación escribiendo manualmente `/login`.

## 4. AuthService

El servicio se encarga de:

- Validar las credenciales de demostración.
- Crear un JWT académico con fecha de expiración.
- Guardar token y usuario en `localStorage`.
- Verificar que el token no esté vencido.
- Verificar que los datos del usuario sean válidos.
- Limpiar completamente la sesión cuando el token o el usuario son inválidos.
- Eliminar token y usuario durante el logout.

Credenciales:

```text
admin@guardapp.com
123456
```

## 5. AuthInterceptor

El interceptor consulta el token mediante `AuthService.getToken()`.

- Con token válido, clona la solicitud y agrega:

```text
Authorization: Bearer <token>
```

- Sin token, envía la solicitud sin modificarla.

## 6. Configuración de rutas

```ts
export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
  {
    path: 'login',
    canActivate: [GuestGuard],
    loadComponent: () =>
      import('./features/auth/login/login.component').then(
        (module) => module.LoginComponent,
      ),
  },
  {
    path: 'dashboard',
    canActivate: [AuthGuard],
    loadComponent: () =>
      import('./features/dashboard/dashboard.component').then(
        (module) => module.DashboardComponent,
      ),
  },
  { path: '**', redirectTo: 'dashboard' },
];
```

El Login y el Dashboard mantienen Lazy Loading mediante `loadComponent()`.

## 7. Validación de los seis casos

| N.° | Escenario | Resultado implementado | Evidencia |
|---:|---|---|---|
| 1 | Acceder a `/login` sin autenticarse | Se muestra el Login | `evidencias/caso-01-login-sin-autenticacion.png` |
| 2 | Acceder a `/dashboard` sin autenticarse | AuthGuard redirige a `/login` | `evidencias/caso-02-dashboard-sin-autenticacion.png` |
| 3 | Iniciar sesión con credenciales válidas | Se guarda la sesión y se muestra el Dashboard | `evidencias/caso-03-login-valido-dashboard.png` |
| 4 | Acceder a `/login` estando autenticado | GuestGuard redirige a `/dashboard` | `evidencias/caso-04-login-autenticado.png` |
| 5 | Cerrar sesión | Se eliminan token y usuario y se muestra el Login | `evidencias/caso-05-cerrar-sesion.png` |
| 6 | Acceder a `/dashboard` después del logout | AuthGuard vuelve a redirigir al Login | `evidencias/caso-06-dashboard-despues-logout.png` |

Los casos están automatizados en `e2e/guards.spec.ts`.

## 8. Mejoras incorporadas

- Validación del vencimiento del token.
- Validación de la información del usuario almacenado.
- Limpieza automática de sesiones corruptas.
- Redirección segura únicamente hacia `/dashboard`.
- Sincronización del estado de autenticación entre pestañas.
- Pruebas unitarias del servicio, Guards, interceptor y rutas.
- Pruebas E2E de los seis escenarios y de credenciales incorrectas.
- Scripts de inicio y prueba para Windows.
- Verificador estructural ejecutable con `npm run verify`.

## 9. Conclusión

La aplicación cumple con la protección exclusiva del Dashboard mediante `AuthGuard`, impide el acceso al Login de usuarios autenticados mediante `GuestGuard`, conserva Lazy Loading, adjunta el token con el interceptor y elimina correctamente la sesión al cerrar sesión.
