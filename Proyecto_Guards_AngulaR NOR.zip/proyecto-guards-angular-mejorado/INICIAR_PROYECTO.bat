@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ==============================================
echo  PROYECTO ANGULAR - AUTHGUARD Y GUESTGUARD
echo ==============================================

where node >nul 2>&1
if errorlevel 1 (
  echo ERROR: Node.js no esta instalado.
  echo Instala Node.js 22 LTS y vuelve a ejecutar este archivo.
  pause
  exit /b 1
)

call npm install
if errorlevel 1 (
  echo ERROR: No se pudieron instalar las dependencias.
  echo Revisa tu conexion a Internet y vuelve a intentarlo.
  pause
  exit /b 1
)

call npm run verify
if errorlevel 1 (
  pause
  exit /b 1
)

call npm start
pause
