# Proyecto Angular mejorado: AuthGuard y GuestGuard

Aplicación Angular completa para la actividad **Implementación de Guards para el control de acceso**. El proyecto conserva Lazy Loading y aplica los controles exactamente sobre las rutas solicitadas:

- `/dashboard`: protegido con `AuthGuard`.
- `/login`: protegido con `GuestGuard`.

## Credenciales de prueba

- Correo: `admin@guardapp.com`
- Contraseña: `123456`

> El JWT se genera localmente solo para fines académicos. En una aplicación real debe ser emitido y validado por un backend seguro.

## Requisitos

- Node.js 20.19, 22.12 o 24, de preferencia Node.js 22 LTS.
- npm 10 o superior.
- Google Chrome para las pruebas unitarias con Karma.

## Inicio rápido en Windows

1. Descomprime el ZIP.
2. Abre la carpeta del proyecto.
3. Ejecuta `INICIAR_PROYECTO.bat`.
4. El script instalará las dependencias, verificará la estructura y abrirá la aplicación.

También puedes usar la terminal:

```bash
npm install
npm run verify
npm start
```

La aplicación se abre en `http://localhost:4200`.

## Comandos disponibles

```bash
npm start              # Ejecuta Angular y abre el navegador
npm run verify         # Verifica estructura, rutas y Guards sin compilar
npm run build          # Compila la versión de producción
npm test               # Ejecuta pruebas unitarias en ChromeHeadless
npm run e2e:install    # Instala Chromium para Playwright
npm run e2e            # Ejecuta los seis casos y regenera capturas reales
npm run check          # Verificación estructural + compilación
```

## Casos de validación incluidos

1. `/login` sin autenticación muestra el Login.
2. `/dashboard` sin autenticación redirige al Login.
3. Credenciales válidas muestran el Dashboard.
4. `/login` con sesión iniciada redirige al Dashboard.
5. Cerrar sesión elimina token y usuario, y muestra el Login.
6. `/dashboard` después del logout redirige nuevamente al Login.

Además se valida que las credenciales incorrectas no creen una sesión.

## Pruebas incluidas

- `AuthGuard`: acceso permitido y redirección.
- `GuestGuard`: acceso de invitado y redirección del autenticado.
- `AuthService`: login válido, login inválido, logout y token vencido.
- `AuthInterceptor`: encabezado `Authorization: Bearer` con token y ausencia del encabezado sin token.
- Rutas: aplicación correcta de cada Guard y Lazy Loading.
- Playwright E2E: seis escenarios requeridos más una validación adicional.

## Estructura principal

```text
src/app/
├── core/
│   ├── guards/
│   │   ├── auth.guard.ts
│   │   ├── auth.guard.spec.ts
│   │   ├── guest.guard.ts
│   │   └── guest.guard.spec.ts
│   ├── interceptors/
│   │   ├── auth.interceptor.ts
│   │   └── auth.interceptor.spec.ts
│   ├── models/auth.models.ts
│   └── services/
│       ├── auth.service.ts
│       └── auth.service.spec.ts
├── features/
│   ├── auth/login/
│   └── dashboard/
├── app.routes.ts
└── app.routes.spec.ts
```

La explicación de entrega está en `DOCUMENTACION.md`. Las imágenes se encuentran en `evidencias/`; al ejecutar `npm run e2e` se reemplazan con capturas obtenidas de la aplicación en ejecución.
