import { routes } from './app.routes';
import { AuthGuard } from './core/guards/auth.guard';
import { GuestGuard } from './core/guards/guest.guard';

describe('Configuración de rutas', () => {
  it('protege únicamente /dashboard con AuthGuard', () => {
    const dashboard = routes.find((route) => route.path === 'dashboard');
    const login = routes.find((route) => route.path === 'login');

    expect(dashboard?.canActivate).toEqual([AuthGuard]);
    expect(login?.canActivate ?? []).not.toContain(AuthGuard);
  });

  it('protege /login con GuestGuard', () => {
    const login = routes.find((route) => route.path === 'login');

    expect(login?.canActivate).toEqual([GuestGuard]);
  });

  it('mantiene lazy loading en Login y Dashboard', () => {
    const login = routes.find((route) => route.path === 'login');
    const dashboard = routes.find((route) => route.path === 'dashboard');

    expect(login?.loadComponent).toBeDefined();
    expect(dashboard?.loadComponent).toBeDefined();
  });
});
