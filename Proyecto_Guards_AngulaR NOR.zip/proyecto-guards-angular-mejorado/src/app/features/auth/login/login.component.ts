import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { finalize } from 'rxjs';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginComponent {
  private readonly formBuilder = inject(FormBuilder);
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);

  readonly loading = signal(false);
  readonly errorMessage = signal('');
  readonly returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');
  readonly loggedOut = this.route.snapshot.queryParamMap.get('loggedOut') === '1';

  readonly form = this.formBuilder.nonNullable.group({
    email: [
      'admin@guardapp.com',
      [Validators.required, Validators.email],
    ],
    password: ['', [Validators.required, Validators.minLength(6)]],
  });

  submit(): void {
    this.errorMessage.set('');
    this.form.markAllAsTouched();

    if (this.form.invalid || this.loading()) {
      return;
    }

    this.loading.set(true);
    this.authService
      .login(this.form.getRawValue())
      .pipe(finalize(() => this.loading.set(false)))
      .subscribe((result) => {
        if (!result.success) {
          this.errorMessage.set(result.message ?? 'No fue posible iniciar sesión.');
          return;
        }

        void this.router.navigateByUrl(this.resolveDestination(), {
          replaceUrl: true,
        });
      });
  }

  private resolveDestination(): string {
    if (this.returnUrl === '/dashboard' || this.returnUrl?.startsWith('/dashboard?')) {
      return this.returnUrl;
    }

    return '/dashboard';
  }

  hasError(controlName: 'email' | 'password', errorName: string): boolean {
    const control = this.form.controls[controlName];
    return control.touched && control.hasError(errorName);
  }
}
