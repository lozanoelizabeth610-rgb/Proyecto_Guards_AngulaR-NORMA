import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { AuthService } from './auth.service';

describe('AuthService', () => {
  let service: AuthService;

  beforeEach(() => {
    localStorage.clear();
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthService);
  });

  afterEach(() => {
    localStorage.clear();
  });

  it('inicia sesión con credenciales válidas y almacena el token', fakeAsync(() => {
    let success = false;

    service
      .login({ email: 'ADMIN@GUARDAPP.COM ', password: '123456' })
      .subscribe((result) => {
        success = result.success;
      });

    tick(350);

    expect(success).toBeTrue();
    expect(localStorage.getItem(AuthService.TOKEN_KEY)).toBeTruthy();
    expect(localStorage.getItem(AuthService.USER_KEY)).toContain('admin@guardapp.com');
    expect(service.isAuthenticated()).toBeTrue();
  }));

  it('rechaza credenciales inválidas sin crear una sesión', fakeAsync(() => {
    let resultMessage = '';

    service
      .login({ email: 'admin@guardapp.com', password: 'incorrecta' })
      .subscribe((result) => {
        resultMessage = result.message ?? '';
      });

    tick(350);

    expect(resultMessage).toContain('Credenciales incorrectas');
    expect(localStorage.getItem(AuthService.TOKEN_KEY)).toBeNull();
    expect(service.isAuthenticated()).toBeFalse();
  }));

  it('elimina completamente la sesión al cerrar sesión', fakeAsync(() => {
    service
      .login({ email: 'admin@guardapp.com', password: '123456' })
      .subscribe();
    tick(350);

    service.logout();

    expect(localStorage.getItem(AuthService.TOKEN_KEY)).toBeNull();
    expect(localStorage.getItem(AuthService.USER_KEY)).toBeNull();
    expect(service.isAuthenticated()).toBeFalse();
  }));

  it('rechaza y elimina un token vencido', () => {
    const now = Math.floor(Date.now() / 1000);
    const header = btoa(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
    const payload = btoa(JSON.stringify({ exp: now - 60 }));
    localStorage.setItem(AuthService.TOKEN_KEY, `${header}.${payload}.firma`);
    localStorage.setItem(
      AuthService.USER_KEY,
      JSON.stringify({
        id: 1,
        name: 'Usuario Demo',
        email: 'admin@guardapp.com',
        role: 'Administrador',
      }),
    );

    expect(service.getToken()).toBeNull();
    expect(localStorage.getItem(AuthService.TOKEN_KEY)).toBeNull();
    expect(localStorage.getItem(AuthService.USER_KEY)).toBeNull();
  });
});
