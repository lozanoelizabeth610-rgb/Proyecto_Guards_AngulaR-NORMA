import { Injectable, signal } from '@angular/core';
import { Observable, map, timer } from 'rxjs';
import {
  AuthUser,
  JwtPayload,
  LoginCredentials,
  LoginResult,
} from '../models/auth.models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  static readonly TOKEN_KEY = 'guard_app_token';
  static readonly USER_KEY = 'guard_app_user';

  private readonly demoUser: AuthUser = {
    id: 1,
    name: 'Usuario Demo',
    email: 'admin@guardapp.com',
    role: 'Administrador',
  };

  private readonly authenticatedState = signal<boolean>(this.hasValidSession());
  readonly authenticated = this.authenticatedState.asReadonly();

  constructor() {
    if (typeof window !== 'undefined') {
      window.addEventListener('storage', () => {
        this.authenticatedState.set(this.hasValidSession());
      });
    }
  }

  login(credentials: LoginCredentials): Observable<LoginResult> {
    const email = credentials.email.trim().toLowerCase();

    return timer(350).pipe(
      map(() => {
        const validCredentials =
          email === this.demoUser.email && credentials.password === '123456';

        if (!validCredentials) {
          return {
            success: false,
            message: 'Credenciales incorrectas. Verifica el correo y la contraseña.',
          } satisfies LoginResult;
        }

        const storage = this.getStorage();
        if (!storage) {
          return {
            success: false,
            message: 'El navegador no permite almacenar la sesión.',
          } satisfies LoginResult;
        }

        const token = this.createDemoJwt(this.demoUser);
        storage.setItem(AuthService.TOKEN_KEY, token);
        storage.setItem(AuthService.USER_KEY, JSON.stringify(this.demoUser));
        this.authenticatedState.set(true);

        return { success: true } satisfies LoginResult;
      }),
    );
  }

  logout(): void {
    this.clearSession();
  }

  getToken(): string | null {
    const storage = this.getStorage();
    const token = storage?.getItem(AuthService.TOKEN_KEY) ?? null;

    if (!token || !this.isTokenValid(token)) {
      this.clearSession();
      return null;
    }

    return token;
  }

  isAuthenticated(): boolean {
    const isValid = this.hasValidSession();
    this.authenticatedState.set(isValid);
    return isValid;
  }

  getCurrentUser(): AuthUser | null {
    const storage = this.getStorage();
    const storedUser = storage?.getItem(AuthService.USER_KEY) ?? null;

    if (!storedUser || !this.getToken()) {
      this.clearSession();
      return null;
    }

    try {
      const user = JSON.parse(storedUser) as Partial<AuthUser>;
      if (!this.isValidUser(user)) {
        this.clearSession();
        return null;
      }
      return user;
    } catch {
      this.clearSession();
      return null;
    }
  }

  private hasValidSession(): boolean {
    const storage = this.getStorage();
    if (!storage) {
      return false;
    }

    const token = storage.getItem(AuthService.TOKEN_KEY);
    const rawUser = storage.getItem(AuthService.USER_KEY);

    if (!token || !rawUser || !this.isTokenValid(token)) {
      return false;
    }

    try {
      return this.isValidUser(JSON.parse(rawUser) as Partial<AuthUser>);
    } catch {
      return false;
    }
  }

  private isValidUser(user: Partial<AuthUser>): user is AuthUser {
    return (
      typeof user.id === 'number' &&
      typeof user.name === 'string' &&
      typeof user.email === 'string' &&
      typeof user.role === 'string'
    );
  }

  private isTokenValid(token: string): boolean {
    try {
      const parts = token.split('.');
      if (parts.length !== 3 || !parts[1]) {
        return false;
      }

      const payload = JSON.parse(this.decodeBase64Url(parts[1])) as Partial<JwtPayload>;
      return (
        typeof payload.exp === 'number' &&
        payload.exp > Math.floor(Date.now() / 1000)
      );
    } catch {
      return false;
    }
  }

  private createDemoJwt(user: AuthUser): string {
    const now = Math.floor(Date.now() / 1000);
    const header = { alg: 'HS256', typ: 'JWT' };
    const payload: JwtPayload = {
      sub: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      iat: now,
      exp: now + 60 * 60,
    };

    const encodedHeader = this.encodeBase64Url(JSON.stringify(header));
    const encodedPayload = this.encodeBase64Url(JSON.stringify(payload));
    const demoSignature = this.encodeBase64Url('firma-de-demostracion');

    return `${encodedHeader}.${encodedPayload}.${demoSignature}`;
  }

  private encodeBase64Url(value: string): string {
    return btoa(value).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  }

  private decodeBase64Url(value: string): string {
    const normalized = value.replace(/-/g, '+').replace(/_/g, '/');
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, '=');
    return atob(padded);
  }

  private clearSession(): void {
    const storage = this.getStorage();
    storage?.removeItem(AuthService.TOKEN_KEY);
    storage?.removeItem(AuthService.USER_KEY);
    this.authenticatedState.set(false);
  }

  private getStorage(): Storage | null {
    if (typeof window === 'undefined') {
      return null;
    }

    try {
      return window.localStorage;
    } catch {
      return null;
    }
  }
}
