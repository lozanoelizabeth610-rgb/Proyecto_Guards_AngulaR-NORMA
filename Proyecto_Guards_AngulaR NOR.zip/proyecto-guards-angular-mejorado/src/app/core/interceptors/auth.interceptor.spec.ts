import {
  HttpClient,
  provideHttpClient,
  withInterceptors,
} from '@angular/common/http';
import {
  HttpTestingController,
  provideHttpClientTesting,
} from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { AuthService } from '../services/auth.service';
import { authInterceptor } from './auth.interceptor';

describe('authInterceptor', () => {
  let http: HttpClient;
  let httpTesting: HttpTestingController;
  let authService: jasmine.SpyObj<AuthService>;

  beforeEach(() => {
    authService = jasmine.createSpyObj<AuthService>('AuthService', ['getToken']);

    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptors([authInterceptor])),
        provideHttpClientTesting(),
        { provide: AuthService, useValue: authService },
      ],
    });

    http = TestBed.inject(HttpClient);
    httpTesting = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpTesting.verify();
  });

  it('agrega Authorization Bearer cuando existe token', () => {
    authService.getToken.and.returnValue('token-prueba');

    http.get('/api/perfil').subscribe();

    const request = httpTesting.expectOne('/api/perfil');
    expect(request.request.headers.get('Authorization')).toBe(
      'Bearer token-prueba',
    );
    request.flush({});
  });

  it('no agrega Authorization cuando no existe token', () => {
    authService.getToken.and.returnValue(null);

    http.get('/api/publico').subscribe();

    const request = httpTesting.expectOne('/api/publico');
    expect(request.request.headers.has('Authorization')).toBeFalse();
    request.flush({});
  });
});
