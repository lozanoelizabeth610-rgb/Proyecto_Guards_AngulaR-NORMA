import { TestBed } from '@angular/core/testing';
import { Router, UrlTree } from '@angular/router';
import { GuestGuard } from './guest.guard';
import { AuthService } from '../services/auth.service';

describe('GuestGuard', () => {
  let guard: GuestGuard;
  let authService: jasmine.SpyObj<AuthService>;
  let router: jasmine.SpyObj<Router>;

  beforeEach(() => {
    authService = jasmine.createSpyObj<AuthService>('AuthService', ['isAuthenticated']);
    router = jasmine.createSpyObj<Router>('Router', ['createUrlTree']);

    TestBed.configureTestingModule({
      providers: [
        GuestGuard,
        { provide: AuthService, useValue: authService },
        { provide: Router, useValue: router },
      ],
    });

    guard = TestBed.inject(GuestGuard);
  });

  it('permite abrir el Login cuando el usuario no está autenticado', () => {
    authService.isAuthenticated.and.returnValue(false);

    const result = guard.canActivate({} as never, {} as never);

    expect(result).toBeTrue();
    expect(router.createUrlTree).not.toHaveBeenCalled();
  });

  it('redirige al Dashboard cuando el usuario autenticado intenta abrir el Login', () => {
    const urlTree = {} as UrlTree;
    authService.isAuthenticated.and.returnValue(true);
    router.createUrlTree.and.returnValue(urlTree);

    const result = guard.canActivate({} as never, {} as never);

    expect(router.createUrlTree).toHaveBeenCalledOnceWith(['/dashboard']);
    expect(result).toBe(urlTree);
  });
});
