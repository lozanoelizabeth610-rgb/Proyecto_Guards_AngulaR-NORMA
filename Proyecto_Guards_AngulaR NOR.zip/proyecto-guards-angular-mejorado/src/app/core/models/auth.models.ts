export interface LoginCredentials {
  email: string;
  password: string;
}

export interface AuthUser {
  id: number;
  name: string;
  email: string;
  role: string;
}

export interface LoginResult {
  success: boolean;
  message?: string;
}

export interface JwtPayload {
  sub: number;
  name: string;
  email: string;
  role: string;
  iat: number;
  exp: number;
}
